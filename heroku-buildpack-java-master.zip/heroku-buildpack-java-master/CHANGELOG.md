# Java Buildpack Changelog

## Master

+ Use latest version of Maven by default

## v41

+ Upgrade to Maven 3.3.9
+ Add retry option to curl commands

## v40

+ Added dependency:list to maven commands

## v39

Upgrade JDK and Maven

+ Upgrade default Maven to 3.3.3
+ Upgrade default JDK to 8u51

## v38

Added a new config var for customizing Maven options

+ Added MAVEN_JAVA_OPTS variable
