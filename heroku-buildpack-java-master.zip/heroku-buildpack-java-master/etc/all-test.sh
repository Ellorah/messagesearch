./etc/docker-test.sh &&
./etc/hatchet-test.sh
