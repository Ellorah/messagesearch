App Indexing API: Get your Android app into Search autocomplete
==============

This repository contains the code for the App Indexing API codelab.
Please refer to the [codelab page](https://codelabs.developers.google.com/codelabs/app-indexing/#0)
for usage instructions.
